package com.example.weather_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class SearchResult extends AppCompatActivity {

    RelativeLayout relativeLayout;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);
        String data = getIntent().getExtras().getString("data");
        String city = getIntent().getExtras().getString("city");

        relativeLayout = findViewById(R.id.progres_lay);
        linearLayout = findViewById(R.id.all_cards);
        relativeLayout.setVisibility(View.VISIBLE);
        linearLayout.setVisibility(View.GONE);

        Toolbar topbar = (Toolbar) findViewById(R.id.title);
        topbar.setTitle(city);
        topbar.setNavigationIcon(R.drawable.leftarrow);
        topbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SearchResult.this.finish();
            }
        });

        Thread thread = new Thread() {

            @Override
            public void run() {

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() { relativeLayout.setVisibility(View.GONE);
                        linearLayout.setVisibility(View.VISIBLE) ;
                                      }
                });

            }

        };

        thread.start();


        Fragment fragment = new dot1(data,city);

        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame,fragment);

        fragmentTransaction.commit();



    }
}

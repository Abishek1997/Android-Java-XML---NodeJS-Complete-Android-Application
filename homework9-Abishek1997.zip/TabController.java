package com.example.weather_app;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class TabController extends FragmentPagerAdapter {
    private final List<Fragment> Fragments=new ArrayList<>();
    private final List<String> FragmentHeader =new ArrayList<>();
    public TabController(FragmentManager fm){
        super(fm);
    }

    public void newFragmentCreator(Fragment newFragment, String Header){
        Fragments.add(newFragment);
        FragmentHeader.add(Header);
    }
    @Nullable
    @Override
    public CharSequence getPageTitle(int location) {
        return FragmentHeader.get(location);
    }

    @Override
    public Fragment getItem(int i) {
        return Fragments.get(i);
    }

    @Override
    public int getCount() {
        return Fragments.size();
    }
}

package com.example.weather_app;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.DecimalFormat;
import java.util.ArrayList;

import java.util.Calendar;
import java.util.Date;
public class dot1 extends Fragment {


    public dot1(String data, String city) {
        this.city = city;
        this.data = data;
    }

    private Double h_temp;
    private int humidity;
    private Double windSpeed;
    private Double visibility;
    private Double pressure;
    private ArrayList<String> dates = new ArrayList<>();
    private ArrayList<Integer> icons = new ArrayList<>();
    private ArrayList<Integer> tempLows = new ArrayList<>();
    private ArrayList<Integer> tempHighs = new ArrayList<>();
    private Integer temperature;
    private String summary;
    private Integer icon;
    private String ic;
    String data = ";";
    String city = ":";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    FloatingActionButton flb;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_dot1, container, false);
        sharedPreferences = getContext().getSharedPreferences("abishek", Context.MODE_PRIVATE);


        JSONObject reader = null;
        JSONObject currently = null;
        JSONObject daily = null;
        JSONArray dailyArray = null;

        try {
            reader =  new JSONObject(data);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            currently = reader.getJSONObject("currently");
            temperature  = currently.getInt("temperature");
            summary = currently.getString("summary");
            ic = currently.getString("icon");

            if(ic.equals("clear-day")){
                icon = R.drawable.clearday;
            }
            else if (ic.equals("clear-night")){
                icon = R.drawable.clearnight;
            }
            else if(ic.equals("rain")){
                icon = R.drawable.rain;
            }
            else if(ic.equals("sleet")){
                icon = R.drawable.snowy;
            }
            else if(ic.equals("snow")){
                icon = R.drawable.snowyonly;
            }
            else if(ic.equals("wind")){
                icon = R.drawable.windy;
            }
            else if (ic.equals("fog")){
                icon = R.drawable.foggy;
            }
            else if(ic.equals("cloudy")){
                icon = R.drawable.cloudy;
            }
            else if (ic.equals("partly-cloudy-night")){
                icon = R.drawable.nightcloudy;
            }
            else {
                icon = R.drawable.partlycloudy;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            daily = reader.getJSONObject("daily");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            dailyArray = daily.getJSONArray("data");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            h_temp = currently.getDouble("humidity");
            h_temp *= 100;
            humidity = (int) Math.round(h_temp * 100)/100;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            windSpeed = currently.getDouble("windSpeed");
            windSpeed = Math.round(windSpeed * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            visibility = currently.getDouble("visibility");
            visibility = Math.round(visibility * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            pressure = currently.getDouble("pressure");
            pressure = Math.round(pressure * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        TextView tvtemp = view.findViewById(R.id.temp);
        tvtemp.setText(temperature.toString() + " \u00B0F");
        TextView tvsummary = view.findViewById(R.id.summary);
        tvsummary.setText(summary);
        ImageView icontv = view.findViewById(R.id.cardIcon);
        icontv.setImageResource(icon);
        TextView tvcity = view.findViewById(R.id.city);
        tvcity.setText(city);
        TextView tv1 = view.findViewById(R.id.humidity);
        TextView tv2 = view.findViewById(R.id.windspeed);
        TextView tv3 = view.findViewById(R.id.visibility);
        TextView tv4 = view.findViewById(R.id.pressure);

        tv1.setText(String.valueOf(humidity) + " %");
        tv2.setText(windSpeed.toString() + " mph");
        tv3.setText(visibility.toString() + " km");
        tv4.setText(pressure.toString() + " mb");

        dates = new ArrayList<String>();
        icons = new ArrayList<Integer>();
        tempHighs = new ArrayList<Integer>();
        tempLows = new ArrayList<Integer>();
        DecimalFormat formatter = new DecimalFormat("00");

        for (int i=0;i<dailyArray.length();i++){

            try {
                Long time = dailyArray.getJSONObject(i).getLong("time");
                Date date= new Date(time*1000);
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                int year = cal.get(Calendar.YEAR);
                int t_month = cal.get(Calendar.MONTH) + 1;
                String month = formatter.format(t_month);
                int t_day = cal.get(Calendar.DAY_OF_MONTH);
                String day = formatter.format(t_day);
                String _date = month + "/" + day + "/" + year;
                dates.add(_date);
                String icon = dailyArray.getJSONObject(i).getString("icon");
                Integer templow = dailyArray.getJSONObject(i).getInt("temperatureLow");
                Integer temphigh = dailyArray.getJSONObject(i).getInt("temperatureHigh");

                tempLows.add(templow);
                tempHighs.add(temphigh);

                if(icon.equals("clear-day")){
                    icons.add(R.drawable.clearday);
                }
                else if (icon.equals("clear-night")){
                    icons.add(R.drawable.clearnight);
                }
                else if(icon.equals("rain")){
                    icons.add(R.drawable.rain);
                }
                else if(icon.equals("sleet")){
                    icons.add(R.drawable.snowy);
                }
                else if(icon.equals("snow")){
                    icons.add(R.drawable.snowyonly);
                }
                else if(icon.equals("wind")){
                    icons.add(R.drawable.windy);
                }
                else if (icon.equals("fog")){
                    icons.add(R.drawable.foggy);
                }
                else if(icon.equals("cloudy")){
                    icons.add(R.drawable.cloudy);
                }
                else if (icon.equals("partly-cloudy-night")){
                    icons.add(R.drawable.nightcloudy);
                }
                else {
                    icons.add(R.drawable.partlycloudy);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        CardView cardView = (CardView) view.findViewById(R.id.cvdot1);
        cardView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.putExtra("session1", data);
                intent.putExtra("city",city);
                startActivity(intent);
            }
        });

        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),1));
        DotAdapterClass adapter = new DotAdapterClass(tempLows,tempHighs,icons, dates,getContext());
        recyclerView.setAdapter(adapter);


        flb = (FloatingActionButton) view.findViewById(R.id.fb);
        if (city.equals("Los Angeles,CA,US"))
            flb.setVisibility(View.GONE);

        if(sharedPreferences.contains(city))
        flb.setImageResource(R.drawable.map_minus);

        else
        flb.setImageResource(R.drawable.map_plus);

        flb.setOnClickListener(new FloatingActionButton.OnClickListener(){

            @Override
            public void onClick(View view) {
                editor = sharedPreferences.edit();
                if(!sharedPreferences.contains(city))
                {
                    Toast toast = Toast.makeText(getContext(),city + " was added to favorites",Toast.LENGTH_SHORT);
                    View v = toast.getView();
                    v.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
                    TextView text_v = v.findViewById(android.R.id.message);
                    text_v.setTextColor(Color.BLACK);
                    toast.show();
                    editor.putString(city,data);
                    flb.setImageResource(R.drawable.map_minus);}
                else{
                    Toast toast = Toast.makeText(getContext(),city + " was removed from favorites",Toast.LENGTH_SHORT);
                    View v = toast.getView();
                    v.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
                    TextView text_v = v.findViewById(android.R.id.message);
                    text_v.setTextColor(Color.BLACK);

                    toast.show();
                    editor.remove(city);
                    flb.setImageResource(R.drawable.map_plus);}
                editor.apply();

            }
        });
        return view;
    }



}

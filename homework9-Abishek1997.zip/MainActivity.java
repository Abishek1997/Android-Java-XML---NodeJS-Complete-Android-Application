package com.example.weather_app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.RequiresApi;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    RelativeLayout relativeLayout;
    LinearLayout linearLayout;

    private TabController tabController;
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private int[] tabIcons = {
            R.drawable.today,
            R.drawable.weekly,
            R.drawable.photos
    };
    tab1 Tab1 = new tab1();
    tab2 Tab2 = new tab2();
    tab3 Tab3 = new tab3();
    String data;
    String city;
    String img_city;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        relativeLayout = findViewById(R.id.progres_lay);
        linearLayout = findViewById(R.id.all_tabs);

        relativeLayout.setVisibility(View.VISIBLE);
        linearLayout.setVisibility(View.GONE);

        Thread thread = new Thread() {

            @Override
            public void run() {

                // Block this thread for 2 seconds.
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                }

                // After sleep finished blocking, create a Runnable to run on the UI Thread.
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() { relativeLayout.setVisibility(View.GONE);
                        linearLayout.setVisibility(View.VISIBLE) ;
                                        }
                });

            }

        };

// Don't forget to start the thread.
        thread.start();
        Toolbar topbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(topbar);
        topbar.setNavigationIcon(R.drawable.leftarrow);
        topbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.finish();
            }
        });
        ViewPager viewPager = findViewById(R.id.view_pager);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        tabController = new TabController(getSupportFragmentManager());
        viewPager = (ViewPager)(findViewById(R.id.view_pager));
        try {
            dataget();
            imgGet();
//            Log.d("CURR","title " + city);
            getSupportActionBar().setTitle(city);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        tabController.newFragmentCreator(Tab1,"Today");
        tabController.newFragmentCreator(Tab2,"Weekly");
        tabController.newFragmentCreator(Tab3,"Photos");

        viewPager.setAdapter(tabController);

        tabLayout = (TabLayout) findViewById(R.id.tabs);

        tabLayout.setupWithViewPager(viewPager);
        for(int i=0;i<3;i++)
        tabLayout.getTabAt(i).setIcon(tabIcons[i]);

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tab.getIcon().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                tab.getIcon().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
    public void twitterFunction(View v){

        Integer temperature = Tab1.getTemperature();
//        Log.d("CURR", String.valueOf(temperature));
//        Log.d("CURR",city);
        String tweet = "Check out " + city + "'s Weather! It is " + temperature + "\u00B0F!";
        Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=" + tweet + ".&hashtags=CSCI571WeatherSearch"));
        startActivity(myIntent);

    }
    public static class HttpGetRequest extends AsyncTask<String, Void, String> {
        public static final String REQUEST_METHOD = "GET";
        public static final int READ_TIMEOUT = 15000;
        public static final int CONNECTION_TIMEOUT = 15000;
        @Override
        protected String doInBackground(String... params){
            String stringUrl = params[0];
            String result;
            String inputLine;
            try {
                URL myUrl = new URL(stringUrl);
                HttpURLConnection connection =(HttpURLConnection)
                        myUrl.openConnection();
                connection.setRequestMethod(REQUEST_METHOD);
                connection.setReadTimeout(READ_TIMEOUT);
                connection.setConnectTimeout(CONNECTION_TIMEOUT);

                connection.connect();
                InputStreamReader streamReader = new
                        InputStreamReader(connection.getInputStream());

                BufferedReader reader = new BufferedReader(streamReader);
                StringBuilder stringBuilder = new StringBuilder();

                while((inputLine = reader.readLine()) != null){
                    stringBuilder.append(inputLine);
                }
                reader.close();
                streamReader.close();
                result = stringBuilder.toString();
            }
            catch(IOException e){
                e.printStackTrace();
                result = null;
            }
            return result;
        }
        protected void onPostExecute(String result){
            super.onPostExecute(result);
        }
    }
    public void dataget() throws ExecutionException, InterruptedException, JSONException {
        //Asynctask call from here

        data = getIntent().getStringExtra("session1");
        city = getIntent().getStringExtra("city");
//        Log.d("CURR", data);
        String currently;
        JSONObject reader = new JSONObject(data);

        JSONObject curr = reader.getJSONObject("currently");
        String week_t1 = reader.getJSONObject("daily").toString();
        currently = curr.toString();
        Bundle bundle_today = new Bundle();
        bundle_today.putString("id", currently);
        Tab1.setArguments(bundle_today);
        Bundle bundle_to_weekly = new Bundle();
        bundle_to_weekly.putString("weekly", week_t1);
        Tab2.setArguments(bundle_to_weekly);
    }
    public void imgGet() throws ExecutionException, InterruptedException, JSONException{

        ArrayList<String> urls = new ArrayList<>();
        String [] arr = city.split(",");
        img_city = arr[0];
        String img_url = "https://android-57711997.appspot.com/get_seal?city=" + img_city;
        img_url = img_url.replace(" ", "%20");
        HttpGetRequest callNode = new HttpGetRequest();
        String img_obj = callNode.execute(img_url).get();
        JSONObject val = new JSONObject(img_obj);
        JSONArray imgArray = val.getJSONArray("items");
        for (int i=0; i<imgArray.length();i++){
            String url = imgArray.getJSONObject(i).getString("link");
            urls.add(url);
        }

        Bundle imgBundle = new Bundle();
        imgBundle.putStringArrayList("img",urls);
        Tab3.setArguments(imgBundle);
    }
}
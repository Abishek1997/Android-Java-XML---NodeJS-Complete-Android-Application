package com.example.weather_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecyclerViewAdapterClass extends RecyclerView.Adapter<RecyclerViewAdapterClass.RecyclerViewHolder> {
    private static final String TAG = "tab1";
    private ArrayList<Integer> icons = new ArrayList<>();
    private ArrayList<String> value = new ArrayList<>();
    private ArrayList<String> desc = new ArrayList<>();
    private Context context;

    public RecyclerViewAdapterClass(ArrayList<Integer> icons, ArrayList<String> value, ArrayList<String> desc, Context context) {
        this.icons = icons;
        this.value = value;
        this.desc = desc;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.from(parent.getContext()).inflate(R.layout.rowlayout,parent,false);
        RecyclerViewHolder rvHolder = new RecyclerViewHolder(view);
        return rvHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        holder.image.setImageResource(icons.get(position));
        holder.iconValue.setText(value.get(position));
        holder.description.setText(desc.get(position));
    }

    @Override
    public int getItemCount() {
        return icons.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder{

        CardView myCard;
        ImageView image;
        TextView iconValue;
        TextView description;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            myCard = itemView.findViewById(R.id.cv);
            image = itemView.findViewById(R.id.icon);
            iconValue = itemView.findViewById(R.id.value);
            description = itemView.findViewById(R.id.description);
        }
    }
}

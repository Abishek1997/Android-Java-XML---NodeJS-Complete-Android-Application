package com.example.weather_app;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListViewAdapter extends ArrayAdapter<String> {
    ArrayList<String > cities =new ArrayList<String>();
    @Nullable
    @Override
    public String getItem(int position) {
        return cities.get(position);
    }

    public ListViewAdapter(Context context, ArrayList<String> cities) {
        super(context, 0, cities);
        this.cities = cities;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
//        Log.d("CURR", position+"");
        String str = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.autocomplete_listview, parent, false);
        }
        TextView tvName = (TextView) convertView.findViewById(R.id.name1);
//        Log.d("CURR",str);
        tvName.setText(str);
        return convertView;
    }
}







//
//public class ListViewAdapter extends BaseAdapter {
//
//    // Declare Variables
//
//    Context mContext;
//    LayoutInflater inflater;
//    private List<String> cities;
//    private String url = "";
//
//    public ListViewAdapter(Context context, List<String> cities) {
//        mContext = context;
//        this.cities = cities;
//        inflater = LayoutInflater.from(mContext);
//    }
//
//    public class ViewHolder {
//        TextView name1;
//    }
//
//    @Override
//    public int getCount() {
//        return cities.size();
//    }
//
//    @Override
//    public String getItem(int position) {
//        return cities.get(position);
//    }
//
//    @Override
//    public long getItemId(int position) {
//        return position;
//    }
//
//    public View getView(final int position, View view, ViewGroup parent) {
//        final ViewHolder holder;
//        if (view == null) {
//            holder = new ViewHolder();
//            view = inflater.inflate(R.layout.autocomplete_listview, null);
//            // Locate the TextViews in listview_item.xml
//            holder.name1 = (TextView) view.findViewById(R.id.name1);
//            view.setTag(holder);
//        } else {
//            holder = (ViewHolder) view.getTag();
//        }
//        // Set the results into TextViews
//        Log.d("CURR", "HERE " + cities.toString());
//        holder.name1.setText(cities.get(position));
//
//        return view;
//    }
//
//    // Filter Class
//    public void filter(String charText) {
//        charText = charText.toLowerCase(Locale.getDefault());
//        cities.clear();
//        if (charText.length() > 0) {
//            url = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=" + charText + "&types=(cities)&&key=AIzaSyAPBlAEy3QbTBuA3rkqRd4UAb9AophJVm0";
//            MainActivity.HttpGetRequest callNode = new MainActivity.HttpGetRequest();
//            String object = null;
//            try {
//                object = callNode.execute(url).get();
//            } catch (ExecutionException e) {
//                e.printStackTrace();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            JSONObject obj = null;
//            try {
//                obj = new JSONObject(object);
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            JSONArray city_array = null;
//            try {
//                city_array = obj.getJSONArray("predictions");
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            for (int i=0;i<city_array.length();i++) {
//                String temp = null;
//                try {
//                    temp = city_array.getJSONObject(i).getString("description");
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//                cities.add(temp);
//            }
//        }
//        notifyDataSetChanged();
//    }
//
//}
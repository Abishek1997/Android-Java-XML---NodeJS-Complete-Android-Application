package com.example.weather_app;


import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class tab2 extends Fragment {


    public tab2() {
        // Required empty public constructor
    }

    private ArrayList<Entry> tempLow = new ArrayList<Entry>();
    private ArrayList<Entry> tempHigh = new ArrayList<Entry>();
    private ArrayList<String> xAxes = new ArrayList<>();
    LineChart lineChart;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        String str = ";";
        str = getArguments().getString("weekly");

        JSONObject reader = null;
        JSONArray arr = null;
        String summary = "";
        String icon = "";

        try {
            reader = new JSONObject(str);
            arr = reader.getJSONArray("data");
            summary = reader.getString("summary");
            icon = reader.getString("icon");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            double x = 0;

            for (int i=0; i<arr.length();i++) {
                float t_h = (float) arr.getJSONObject(i).getDouble("temperatureLow");
                float t_l = (float) arr.getJSONObject(i).getDouble("temperatureHigh");
                tempLow.add(new Entry(i,t_l));
                tempHigh.add(new Entry(i,t_h));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        View view = inflater.inflate(R.layout.fragment_tab2, container, false);
        ImageView image = view.findViewById(R.id.summary_icon);
        if(icon.equals("clear-day")){
            image.setImageResource(R.drawable.clearday);
        }
        else if (icon.equals("clear-night")){
            image.setImageResource(R.drawable.clearnight);
        }
        else if(icon.equals("rain")){
            image.setImageResource(R.drawable.rain);
        }
        else if(icon.equals("sleet")){
            image.setImageResource(R.drawable.snowy);
        }
        else if(icon.equals("snow")){
            image.setImageResource(R.drawable.snowyonly);
        }
        else if(icon.equals("wind")){
            image.setImageResource(R.drawable.windy);
        }
        else if (icon.equals("fog")){
            image.setImageResource(R.drawable.foggy);
        }
        else if(icon.equals("cloudy")){
            image.setImageResource(R.drawable.cloudy);
        }
        else if (icon.equals("partly-cloudy-night")){
            image.setImageResource(R.drawable.nightcloudy);
        }
        else {
            image.setImageResource(R.drawable.partlycloudy);
        }
        TextView text = view.findViewById(R.id.summary_value);
        text.setText(summary);

        lineChart = (LineChart) view.findViewById(R.id.lineChart);
        ArrayList<ILineDataSet> lineDataSets = new ArrayList<>();

        LineDataSet ld1  = new LineDataSet(tempHigh, "Minimum Temperature");
        LineDataSet ld2 = new LineDataSet(tempLow, "Maximum Temperature");
        ld2.setColor(Color.rgb(106,89,53));
        ld2.setCircleColor(Color.WHITE);
        ld2.setLineWidth(2f);
        ld1.setColor(Color.rgb(80,74,100));
        ld1.setCircleColor(Color.WHITE);
        ld1.setLineWidth(2f);
        lineDataSets.add(ld1);
        lineDataSets.add(ld2);

        lineChart.getAxisLeft().setTextColor(Color.rgb(126,126,126));
        lineChart.getAxisRight().setTextColor(Color.rgb(126,126,126));
        lineChart.getXAxis().setTextColor(Color.rgb(126,126,126));
        lineChart.getLegend().setTextColor(Color.WHITE);
        lineChart.getLegend().setTextSize(15);

        lineChart.getXAxis().setDrawGridLines(false);

        lineChart.setData(new LineData(lineDataSets));
        return view;
    }

}

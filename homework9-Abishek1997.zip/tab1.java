package com.example.weather_app;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class tab1 extends Fragment {


    public tab1() {
        // Required empty public constructor
    }

    private static final String TAG = "tab1";

    private ArrayList<Integer> icons = new ArrayList<>();
    private ArrayList<String> value = new ArrayList<>();
    private ArrayList<String> desc = new ArrayList<>();

    private Double windSpeed;
    private Double pressure;
    private Double precipitation;
    private Integer temperature;
    private String icon;
    private int humidity;
    private Double visibility;
    private int cloudcover;
    private Double ozone;
    private Double c_temp;
    private Double h_temp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        String str = ";";
        str = getArguments().getString("id");

        JSONObject reader = null;
        try {
            reader = new JSONObject(str);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            windSpeed = reader.getDouble("windSpeed");
            windSpeed = Math.round(windSpeed * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            pressure = reader.getDouble("pressure");
            pressure = Math.round(pressure * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            precipitation = reader.getDouble("precipIntensity");
            precipitation = Math.round(precipitation * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            temperature = reader.getInt("temperature");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            icon = reader.getString("icon");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            h_temp = reader.getDouble("humidity");
            h_temp *= 100;
            humidity = (int) Math.round(h_temp * 100)/100;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            visibility = reader.getDouble("visibility");
            visibility = Math.round(visibility * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            c_temp = reader.getDouble("cloudCover");
            c_temp *= 100;
            cloudcover = (int) Math.round(c_temp * 100)/100;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            ozone = reader.getDouble("ozone");
            ozone = Math.round(ozone * 100.0)/100.0;
        } catch (JSONException e) {
            e.printStackTrace();
        }


        getData();

        View view = inflater.inflate(R.layout.fragment_tab1, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),3));
        RecyclerViewAdapterClass adapter = new RecyclerViewAdapterClass(icons,value,desc,getContext());
        recyclerView.setAdapter(adapter);
        return view;
    }
    public Integer getTemperature(){
        return temperature;
    }
    private void getData(){
        icons = new ArrayList<Integer>();

        icons.add(R.drawable.windcard);
        icons.add(R.drawable.pressurecard);
        icons.add(R.drawable.raincard);
        icons.add(R.drawable.temperaturecard);
        if(icon.equals("clear-day")){
            icons.add(R.drawable.clearday);
        }
        else if (icon.equals("clear-night")){
            icons.add(R.drawable.clearnight);
        }
        else if(icon.equals("rain")){
            icons.add(R.drawable.rain);
        }
        else if(icon.equals("sleet")){
            icons.add(R.drawable.snowy);
        }
        else if(icon.equals("snow")){
            icons.add(R.drawable.snowyonly);
        }
        else if(icon.equals("wind")){
            icons.add(R.drawable.windy);
        }
        else if (icon.equals("fog")){
            icons.add(R.drawable.foggy);
        }
        else if(icon.equals("cloudy")){
            icons.add(R.drawable.cloudy);
        }
        else if (icon.equals("partly-cloudy-night")){
            icons.add(R.drawable.nightcloudy);
        }
        else {
            icons.add(R.drawable.partlycloudy);
        }
        icons.add(R.drawable.humiditycard);
        icons.add(R.drawable.visibilitycard);
        icons.add(R.drawable.cloudcovercard);
        icons.add(R.drawable.ozonecard);

        value = new ArrayList<String>();
        value.add(windSpeed.toString() + " mph");
        value.add(pressure.toString() + " mb");
        value.add(precipitation.toString() + " mmph");
        value.add(temperature.toString() + " \u00B0F");
        value.add("");
        value.add(humidity + "%");
        value.add(visibility.toString() + " km");
        value.add(cloudcover + "%");
        value.add(ozone.toString() + " DU");

        desc = new ArrayList<String>();
        desc.add("Wind Speed");
        desc.add("Pressure");
        desc.add("Precipitation");
        desc.add("Temperature");
        if (icon.equals("partly-cloudy-day")){
            desc.add("Cloudy day");
        }
        else if (icon.equals("partly-cloudy-night")){
            desc.add("Cloudy night");
        }
        else{
            desc.add(icon);
        }
        desc.add("Humidity");
        desc.add("Visibility");
        desc.add("Cloud Cover");
        desc.add("Ozone");

    }

}

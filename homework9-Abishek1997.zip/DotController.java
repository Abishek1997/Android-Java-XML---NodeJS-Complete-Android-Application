package com.example.weather_app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;


public class DotController extends FragmentStatePagerAdapter {

    private final List<Fragment> Fragments=new ArrayList<>();
    private final List<String> FragmentHeader =new ArrayList<>();
    public DotController(FragmentManager fm){
        super(fm);
    }

    public void newFragmentCreator(Fragment newFragment, String Header){
        Fragments.add(newFragment);
        FragmentHeader.add(Header);
    }
    @Nullable
    @Override
    public CharSequence getPageTitle(int location) {
        return FragmentHeader.get(location);
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    @Override
    public Fragment getItem(int i) {
        return Fragments.get(i);
    }

    @Override
    public int getCount() {
        return Fragments.size();
    }
}

package com.example.weather_app;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PhotoRecyclerAdapterClass extends RecyclerView.Adapter<PhotoRecyclerAdapterClass.RecyclerViewHolder> {
    private static final String TAG = "tab1";

    private ArrayList<String> urls;
    private Context context;

    public PhotoRecyclerAdapterClass(ArrayList<String> urls, Context context) {
        this.urls = urls;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.from(parent.getContext()).inflate(R.layout.photos,parent,false);
        RecyclerViewHolder rvHolder = new RecyclerViewHolder(view);
        return rvHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        Picasso.with(context).load(urls.get(position)).into(holder.image);

    }

    @Override
    public int getItemCount() {
        return urls.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder{

        CardView myCard;
        ImageView image;


        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            myCard = itemView.findViewById(R.id.cv3);
            image = itemView.findViewById(R.id.photo);

        }
    }
}
